# JARVIS Android APK project

This is a native Android Studio project (Java), not a website wrapper. It runs on Android 6.0+ (API 23+) and sends chat/image requests directly to Google's Gemini API. The Gemini key is entered in the app and encrypted using Android Keystore before being stored locally.

## Features in this starter APK
- Native Android chat screen with JARVIS dark/cyan styling
- Gemini 3.8 Flash text chat and image understanding
- Speech-to-text input through Android speech recognition
- Text-to-speech replies
- Camera photo capture (camera thumbnail is sent to Gemini)
- Encrypted local API-key storage using Android Keystore

## Build the APK
1. Install Android Studio on Windows.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the `JARVIS_ANDROID_APK_PROJECT` folder.
4. Allow Gradle sync and install any requested Android SDK Platform 35 / Build Tools.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When it finishes, click **locate** in the notification. The APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer the APK to your Android phone and install it. If Android asks, allow installation from that file manager for this file.

## First launch
1. Open JARVIS.
2. Paste your own Gemini API key into the key field and tap **SAVE KEY**.
3. Type a message or use VOICE / IMAGE.
4. The app needs internet to contact Gemini.

Get a Gemini API key from Google AI Studio: https://aistudio.google.com/app/apikey

## Notes
- This starter is a real native Android app; it does not require the Windows PC or the Flask server.
- Keep the API key private. It is encrypted at rest with Android Keystore, but API calls must send it to Google's Gemini service.
- Speech recognition availability and language support depend on Android speech services installed on the phone.
- Camera currently sends the standard small camera thumbnail returned by Android's camera intent, not a full-resolution capture.
- The app is online-only; chat history is not yet persisted.
- Do not share your APK with your API key embedded; the key is entered separately by each user.

## Model configuration
The app currently uses `gemini-3.8-flash` with the Gemini Developer API `generateContent` endpoint. Google updates model availability over time; if Google changes the model name or endpoint, update the model string in `MainActivity.java`.

## Build from an Android phone (no PC)
This repository includes a GitHub Actions cloud build workflow.
1. In your phone browser, sign in at https://github.com and create a **public or private** repository.
2. Open the repository's **Add file → Upload files** page using your browser's **Desktop site** option if needed.
3. Extract this ZIP using your phone's file manager. Upload the contents of the extracted `JARVIS_ANDROID_APK_PROJECT` folder (including the hidden `.github` folder; if your file picker hides hidden folders, create `.github/workflows/build-apk.yml` directly on GitHub using the workflow file in this project).
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build JARVIS Android APK**. If prompted, enable workflows, then press **Run workflow**.
6. Wait for the workflow to finish successfully. Open its run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it.

A GitHub account is required. Do not add your Gemini API key to the repository. Enter it only inside the installed app.
