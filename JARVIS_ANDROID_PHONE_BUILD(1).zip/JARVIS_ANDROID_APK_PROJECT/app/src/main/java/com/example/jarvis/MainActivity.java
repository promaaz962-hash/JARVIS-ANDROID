package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 10, REQ_CAMERA = 11, REQ_PERMS = 12;
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText prompt, keyInput;
    private TextView status;
    private Button sendButton;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Bitmap pendingImage;
    private boolean speakReplies = true;

    private int cyan = Color.rgb(74, 226, 245);
    private int bg = Color.rgb(4, 15, 27);
    private int panel = Color.rgb(10, 31, 48);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.US);
        });
        addMessage("JARVIS", "Systems online. Enter your Gemini API key in Settings to begin.", false);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, REQ_PERMS);
        }
    }

    private void buildUi() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16), dp(12), dp(16), dp(12));
        outer.setBackgroundColor(bg);
        setContentView(outer);

        TextView title = new TextView(this);
        title.setText("J A R V I S");
        title.setTextColor(cyan); title.setTextSize(24); title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        outer.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        status = new TextView(this);
        status.setText("● OFFLINE — ADD GEMINI KEY");
        status.setTextColor(Color.rgb(255,190,90)); status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        outer.addView(status, new LinearLayout.LayoutParams(-1, dp(26)));

        LinearLayout settings = new LinearLayout(this);
        settings.setOrientation(LinearLayout.HORIZONTAL);
        keyInput = new EditText(this);
        keyInput.setSingleLine(true); keyInput.setHint("Gemini API key"); keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.LTGRAY); keyInput.setTextSize(13);
        keyInput.setInputType(129);
        keyInput.setText(readSecret());
        settings.addView(keyInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button save = button("SAVE KEY");
        save.setOnClickListener(v -> { saveSecret(keyInput.getText().toString().trim()); status.setText("● KEY SAVED ON THIS DEVICE"); status.setTextColor(cyan); hideKeyboard(); });
        settings.addView(save, new LinearLayout.LayoutParams(dp(100), dp(48)));
        outer.addView(settings);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(2, dp(12), 2, dp(12));
        scroll.addView(chat);
        LinearLayout.LayoutParams chatParams = new LinearLayout.LayoutParams(-1, 0, 1);
        chatParams.setMargins(0, dp(10), 0, dp(10));
        outer.addView(scroll, chatParams);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button voice = button("🎙 VOICE");
        voice.setOnClickListener(v -> startVoice());
        Button camera = button("📷 IMAGE");
        camera.setOnClickListener(v -> takePhoto());
        tools.addView(voice, new LinearLayout.LayoutParams(0, dp(46), 1));
        tools.addView(camera, new LinearLayout.LayoutParams(0, dp(46), 1));
        outer.addView(tools);

        prompt = new EditText(this);
        prompt.setHint("Ask JARVIS anything...");
        prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(Color.GRAY);
        prompt.setTextSize(16); prompt.setMinLines(1); prompt.setMaxLines(4);
        prompt.setPadding(dp(12), dp(8), dp(12), dp(8));
        prompt.setBackground(round(panel, 12));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, -2);
        inputParams.setMargins(0, dp(8), 0, dp(8));
        outer.addView(prompt, inputParams);

        sendButton = button("SEND TO JARVIS");
        sendButton.setOnClickListener(v -> sendPrompt());
        outer.addView(sendButton, new LinearLayout.LayoutParams(-1, dp(50)));

        TextView note = new TextView(this);
        note.setText("Gemini AI • Voice • Camera • Private device key storage");
        note.setTextColor(Color.GRAY); note.setTextSize(10); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteP = new LinearLayout.LayoutParams(-1, dp(24));
        noteP.topMargin = dp(4); outer.addView(note, noteP);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.rgb(2,18,29)); b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setAllCaps(false);
        b.setBackground(round(cyan, 10));
        return b;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void hideKeyboard() {
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(prompt.getWindowToken(),0);
    }
    private void addMessage(String who, String text, boolean user) {
        TextView bubble = new TextView(this);
        bubble.setText(who + "\n" + text); bubble.setTextColor(Color.WHITE); bubble.setTextSize(14);
        bubble.setPadding(dp(13),dp(10),dp(13),dp(10));
        bubble.setBackground(round(user ? Color.rgb(16,65,83) : panel, 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,dp(5),0,dp(5)); chat.addView(bubble,p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void sendPrompt() {
        String text = prompt.getText().toString().trim();
        String key = readSecret();
        if (key.isEmpty()) { addMessage("JARVIS", "Please enter and save your Gemini API key first.", false); return; }
        if (text.isEmpty() && pendingImage == null) return;
        prompt.setText(""); hideKeyboard();
        addMessage("YOU", (text.isEmpty() ? "Analyse this image." : text) + (pendingImage != null ? "\n[Image attached]" : ""), true);
        final Bitmap image = pendingImage; pendingImage = null;
        sendButton.setEnabled(false); status.setText("● THINKING...");
        executor.execute(() -> {
            try {
                String answer = callGemini(key, text, image);
                runOnUiThread(() -> {
                    addMessage("JARVIS", answer, false);
                    status.setText("● ONLINE"); sendButton.setEnabled(true);
                    if (speakReplies && tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
                });
            } catch (Exception e) {
                runOnUiThread(() -> { addMessage("JARVIS", "Request failed: " + e.getMessage(), false); status.setText("● CONNECTION ERROR"); sendButton.setEnabled(true); });
            }
        });
    }

    private String callGemini(String key, String text, Bitmap image) throws Exception {
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" + key);
        HttpURLConnection c = (HttpURLConnection)url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
        JSONObject partText = new JSONObject(); partText.put("text", text.isEmpty() ? "Please analyse the attached image." : text);
        JSONArray parts = new JSONArray().put(partText);
        if (image != null) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.JPEG, 82, bytes);
            JSONObject inline = new JSONObject();
            inline.put("mimeType","image/jpeg"); inline.put("data", Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));
            JSONObject imagePart = new JSONObject(); imagePart.put("inlineData",inline); parts.put(imagePart);
        }
        JSONObject content = new JSONObject(); content.put("parts",parts);
        JSONObject body = new JSONObject(); body.put("contents",new JSONArray().put(content));
        JSONObject config = new JSONObject(); config.put("temperature",0.7); config.put("maxOutputTokens",1200);
        body.put("generationConfig",config);
        try (OutputStream out = c.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        java.io.InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        java.io.ByteArrayOutputStream result = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n; while((n=stream.read(buf))!=-1) result.write(buf,0,n);
        String raw = result.toString("UTF-8"); c.disconnect();
        JSONObject response = new JSONObject(raw);
        if (code < 200 || code >= 300) {
            String msg = response.optJSONObject("error") != null ? response.getJSONObject("error").optString("message","Gemini API error") : "HTTP " + code;
            throw new Exception(msg);
        }
        JSONArray candidates = response.optJSONArray("candidates");
        if (candidates == null || candidates.length()==0) return "I couldn't create a response. Please try again.";
        return candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text","No text response.");
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addMessage("JARVIS","Speech recognition is not available on this phone. You can type instead.",false); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC); return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
                public void onReadyForSpeech(Bundle b){ status.setText("● LISTENING..."); }
                public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){status.setText("● PROCESSING VOICE...");}
                public void onError(int e){status.setText("● ONLINE");}
                public void onResults(Bundle b){
                    ArrayList<String> matches=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(matches!=null&&!matches.isEmpty()){prompt.setText(matches.get(0));sendPrompt();}
                }
                public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-PK");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to JARVIS");
            recognizer.startListening(i);
        } catch(Exception e){addMessage("JARVIS","Could not start voice input. Please type your message.",false);}
    }

    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return;
        }
        try { Intent i=new Intent("android.media.action.IMAGE_CAPTURE"); startActivityForResult(i,REQ_CAMERA); }
        catch(Exception e){addMessage("JARVIS","Camera app is unavailable.",false);}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CAMERA && resultCode==RESULT_OK && data!=null && data.getExtras()!=null){
            Object obj=data.getExtras().get("data");
            if(obj instanceof Bitmap){pendingImage=(Bitmap)obj;addMessage("JARVIS","Photo attached. Type a question or press Send.",false);}
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==REQ_MIC && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) startVoice();
        if(requestCode==REQ_CAMERA && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) takePhoto();
    }

    // Encrypt the API key with an Android Keystore AES-GCM key before saving it.
    private SecretKey getSecretKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias("jarvis_api_key")) return ((KeyStore.SecretKeyEntry)ks.getEntry("jarvis_api_key",null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder("jarvis_api_key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }
    private void saveSecret(String value) {
        try {
            if(value.isEmpty()) return;
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,getSecretKey());
            byte[] encrypted=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String stored=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(encrypted,Base64.NO_WRAP);
            getSharedPreferences("jarvis_secure",MODE_PRIVATE).edit().putString("key",stored).apply();
        } catch(Exception e){addMessage("JARVIS","Could not securely save the API key.",false);}
    }
    private String readSecret() {
        try {
            String stored=getSharedPreferences("jarvis_secure",MODE_PRIVATE).getString("key","");
            if(stored.isEmpty()) return "";
            String[] p=stored.split(":"); Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
        } catch(Exception e){return "";}
    }
    @Override protected void onDestroy() {
        if(recognizer!=null) recognizer.destroy();
        if(tts!=null) tts.shutdown();
        executor.shutdown();
        super.onDestroy();
    }
}
